"use strict";
const button = document.querySelector("#get");
const answer = document.querySelector("#answer");
const userName = document.querySelector('input[name="user_name"]');
const userBirthday = document.querySelector('input[name="birth_date"]');

button.onclick = function(e) {
	e.preventDefault();
	const birthDate = new Date(userBirthday.value);
	let alertName = document.createElement("li");
	alertName.innerHTML = "Invalid name";
	alertName.style.color = "red";
	let alertDate = document.createElement("li");
	alertDate.innerHTML = "Invalid date";
	alertDate.style.color = "red";
	if (userBirthday.value.length!==0&&userName.value.length!==0) answer.textContent = `Hello, ${userName.value}! Your golden birthday is on:${birthDate.getDate()}/${birthDate.getMonth()+1}/${birthDate.getFullYear()+birthDate.getDate()}`;
	if (userName.value.length===0) answer.appendChild(alertName);
	if (userBirthday.value.length===0) answer.appendChild(alertDate);
} 
